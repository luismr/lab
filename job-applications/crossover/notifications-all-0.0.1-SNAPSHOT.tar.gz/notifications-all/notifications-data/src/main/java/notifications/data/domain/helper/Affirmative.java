package notifications.data.domain.helper;

/**
 * Affirmative == YES | NO
 * 
 * @author luismr
 *
 */
public enum Affirmative {

	YES, NO;

}
